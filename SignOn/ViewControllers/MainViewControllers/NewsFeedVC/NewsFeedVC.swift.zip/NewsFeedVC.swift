//
//  NewsFeedVC.swift
//  SignOn
//
//  Created by abc on 27/03/19.
//  Copyright © 2019 mobulous. All rights reserved.
//

import UIKit
import RealmSwift

class NewsFeedVC: UIViewController {
    
    //MARK: - OUTLETS
    @IBOutlet weak var tblNewsFeed: UITableView!
    
    //MARK: - VARIABLES
    var homeNewsFeedListModel = [HomeNewsFeedList]()
    var alamObject = AlamofireWrapper()
    let macroObj = MacrosForAll.sharedInstanceMacro
    var dateDate = String()
    var getDate = String()
    let realm = try! Realm()

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        // Do any additional setup after loading the view.
    }
    //MARK: - Actions, Gestures
    //TODO: Actions
    @IBAction func btnBackTapped(_ sender: UIButton) {
        if let userInfo = realm.objects(LoginDataModal.self).first{
            
            if userInfo.isMentor == true{
                let appDel = UIApplication.shared.delegate as! AppDelegate
                _ = appDel.homeMentor()
                
            }else{
                let appDel = UIApplication.shared.delegate as! AppDelegate
                _ = appDel.initHome()
            }
        }
    }
}

//MARK: - Custom methods extension
extension NewsFeedVC{
    //TODO: Method initialSetup
    func initialSetup(){
         tblNewsFeed.tableFooterView = UIView()
         getSignOnFeedData()
        
    }
}

//MARK: - TableView dataSource and delegates extension
extension NewsFeedVC:UITableViewDelegate,UITableViewDataSource{
    //TODO: Number of items in section
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return homeNewsFeedListModel.count
    }

//TODO: Cell for item at indexPath
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //
        tblNewsFeed.register(UINib(nibName: "ImageNewsFeedTableViewCell", bundle: nil), forCellReuseIdentifier: "ImageNewsFeedTableViewCell")
        let cell = tblNewsFeed.dequeueReusableCell(withIdentifier: "ImageNewsFeedTableViewCell", for: indexPath) as! ImageNewsFeedTableViewCell
        cell.nameLbl.text! = homeNewsFeedListModel[indexPath.row].Name
        
        
        
        cell.userNameLbl.attributedText = UpdateUIClass.updateSharedInstance.forNewsFeeedLblMethod("\(homeNewsFeedListModel[indexPath.row].message)")
        
        cell.lblLikeComments.text = "\(homeNewsFeedListModel[indexPath.row].LikeCount) Likes \(homeNewsFeedListModel[indexPath.row].CommentCount) Comment"
        
        let URLString = String(homeNewsFeedListModel[indexPath.row].Url)
        if  URLString == ""{
        }
        else{
            let URL = NSURL(string:URLString)
            let data = NSData(contentsOf: URL! as URL)
            cell.imgView.image =  UIImage(data: data! as Data)
        }
        //Mark: Date And Time Stamp
        
        self.dateDate = String(homeNewsFeedListModel[indexPath.row].Date)
        if self.dateDate == ""{
            
        }
        else{
            updateDate()
            cell.timeLbl.text = self.getDate
        }
        
        // print(endtime)
        
        if homeNewsFeedListModel[indexPath.row].imgPost != ""{
            cell.imgPost.sd_setImage(with: URL(string: homeNewsFeedListModel[indexPath.row].imgPost), placeholderImage: UIImage(named: "groupicon"))
            cell.imgPost.contentMode = .scaleAspectFit
        }else{
            cell.imgPost.frame.size.height = 0
        }
        
        if homeNewsFeedListModel[indexPath.row].feedCommentDate != ""{
            cell.lblComment.isHidden = false
            cell.imgCommentProfile.isHidden = false
            cell.timeLbl.isHidden = false
            cell.lblComment.attributedText = UpdateUIClass.updateSharedInstance.forNewsFeeedLblMethodComments(homeNewsFeedListModel[indexPath.row].feedCommentName,homeNewsFeedListModel[indexPath.row].feedComment)
            cell.imgCommentProfile.sd_setImage(with: URL(string: homeNewsFeedListModel[indexPath.row].feedCommentImgUrl), placeholderImage: UIImage(named: "groupicon"))
        }
        else{
            cell.commentPersonImageHeight.constant = 0
            cell.lblCommentHeight.constant = 0
            cell.timeClockHeight.constant = 0
            cell.heightLblTime.constant = 0
            cell.lblComment.isHidden = true
            cell.imgCommentProfile.isHidden = true
            cell.timeLbl.isHidden = true
        }
        return cell
    }

    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0{
            return UITableView.automaticDimension
            
        }
        else{
            return UITableView.automaticDimension
        }
    }
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
   
}

extension NewsFeedVC{
    func getSignOnFeedData()  {
        //https://portal.signon.co.in/api/v1/feeds?page=1&pageSize=10&isSignOn=true
        if InternetConnection.internetshared.isConnectedToNetwork() {
            
            var token = String()
            
            if let userInfo = realm.objects(LoginDataModal.self).first{
                token = userInfo.token
            }
            
            let header = [
                "Content-Type": "application/json; charset=UTF-8",
                "Authorization" : "Bearer \(token)"
            ]
            // https://portal.signon.co.in/api/v1/feeds?page=1&pageSize=10&isSignOn=false
            macroObj.showLoader(view: self.view)
            alamObject.getRequestURL("/feeds?page=\(1)&pageSize=\(10)&isSignOn=\(false)", headers: header , success: { (responseJASON,responseCode) in
                
                if responseCode == 200{
                    self.macroObj.hideLoader()
                    print(responseJASON)
                    if let dataArr = responseJASON.arrayObject as? NSArray{
                        self.homeNewsFeedListModel.removeAll()
                        for item in dataArr{
                            var r_id = Int()
                            var r_likeCount = Int()
                            var r_feedComment = NSArray()
                            var r_message = String()
                            var r_userDict_Name = String()
                            var r_fcmid = Int()
                            var r_userDictId = Int()
                            var r_phoneVarified = Int()
                            var r_profleImg = String()
                            var r_Url = String()
                            var r_imgUniqueName = String()
                            var r_timeStamp = String()
                            var r_CommentCount = Int()
                            var r_imgPost = String()
                            
                            var r_feedCommentS = String()
                            var r_feedName = String()
                            var r_feedCreatedAt = String()
                            var r_feedProfileImageUrl = String()
                            
                            
                            
                            
                            if let itemDict = item as? NSDictionary{
                                
                                if let attachmentArray = itemDict.value(forKey: "Attachments") as? NSArray{
                                    print(attachmentArray)
                                    if attachmentArray.count > 0{
                                        if let dataDict = attachmentArray.object(at: 0) as? NSDictionary{
                                            guard let imgPost = dataDict.value(forKey: "Url") as? String else{
                                                print("No imgPost")
                                                return
                                            }
                                            
                                            r_imgPost = imgPost
                                        }
                                        
                                    }
                                }
                                
                                
                                if let feedCommentArray = itemDict.value(forKey: "FeedComments") as? NSArray{
                                    if feedCommentArray.count > 0{
                                        if let feedCommentDict = feedCommentArray.object(at: 0) as? NSDictionary{
                                            guard let Comment = feedCommentDict.value(forKey: "Comment") as? String else{
                                                print("No Comment")
                                                return
                                            }
                                            guard let Name = feedCommentDict.value(forKey: "Name") as? String else{
                                                print("No Name")
                                                return
                                            }
                                            guard let CreatedAt = feedCommentDict.value(forKey: "CreatedAt") as? String else{
                                                print("No CreatedAt")
                                                return
                                            }
                                            let ProfileImageUrl = feedCommentDict.value(forKey: "ProfileImageUrl") as? String ?? ""
                                            
                                            
                                            r_feedCommentS = Comment
                                            r_feedName = Name
                                            r_feedCreatedAt = CreatedAt
                                            r_feedProfileImageUrl = ProfileImageUrl
                                        }
                                    }
                                }
                                
                                
                                if let id = itemDict.value(forKey: "Id" ) as? Int{
                                    // .Id = id
                                    print(id)
                                    r_id = id
                                }
                                
                                if let cmntCount = itemDict.value(forKey: "CommentCount" ) as? Int{
                                    // .Id = id
                                    r_CommentCount = cmntCount
                                }
                                
                                if let likeCount = itemDict.value(forKey: "LikeCount" ) as? Int{
                                    r_likeCount = likeCount
                                }
                                if let feedComments = itemDict.value(forKey: "FeedComments" ) as? NSArray{
                                    r_feedComment = feedComments
                                }
                                if let deleted = itemDict.value(forKey: "DeletedAt") as? String{
                                }
                                if let message = itemDict.value(forKey: "Message") as? String{
                                    r_message = message
                                }
                                if let user = itemDict.value(forKey: "User" ) as? NSDictionary{
                                    if let name = (user as AnyObject).value(forKey: "Name") as? String{
                                        r_userDict_Name = name
                                    }
                                    if let fcmid = (user as AnyObject).value(forKey: "FcmIds")as? Int{
                                        r_fcmid = fcmid
                                    }
                                    
                                    if let userdictId = (user as AnyObject).value(forKey: "Id") as? Int{
                                        r_userDictId = userdictId
                                    }
                                    
                                    if let phoneVarified = (user as AnyObject).value(forKey: "IsPhoneVerified") as? Int{
                                        r_phoneVarified = phoneVarified
                                    }
                                    if let profileImage = (user as AnyObject).value(forKey: "ProfileImage") as? NSDictionary{
                                        print(profileImage)
                                        if let imgName = (profileImage as AnyObject).value (forKey: "Name") as? String{
                                            r_profleImg = imgName
                                        }
                                        if let imgUniqueName = (profileImage as AnyObject).value (forKey: "UniqueName") as? String{
                                            r_imgUniqueName = imgUniqueName
                                        }
                                        if let imgUrl = (profileImage as AnyObject).value (forKey: "Url") as? String{
                                            r_Url = imgUrl
                                        }
                                        if let timeStamp = (profileImage as AnyObject).value (forKey: "CreatedAt") as? String{
                                            r_timeStamp = timeStamp
                                        }
                                    }
                                }
                                
                                // print(itemDict)
                            }
                            
                            let homeNewsFeedModelItem = HomeNewsFeedList(id: r_id, name: r_userDict_Name, userName: "", email: "", fcmids: r_fcmid, uniquename: r_imgUniqueName, url: r_Url, isactive: "", userrole: "", isphonevarified: r_phoneVarified, likecount: r_likeCount, commentcount: r_CommentCount, date :r_timeStamp, message: r_message, imgPost: r_imgPost, feedComment: r_feedCommentS, feedCommentImgUrl: r_feedProfileImageUrl, feedCommentName: r_feedName, feedCommentDate: r_feedCreatedAt)
                            self.homeNewsFeedListModel.append(homeNewsFeedModelItem)
                        }
                        print(self.homeNewsFeedListModel)
                        self.tblNewsFeed.reloadData()
                        
                    }
                    
                    //    print(responseJASON)
                }else{
                    self.macroObj.hideLoader()
                    print(responseJASON)
                }
            },
                                     failure: { (error,responseCode) in
                                        print(error.localizedDescription)
                                        self.macroObj.hideLoader()
                                        _ = SweetAlert().showAlert(self.macroObj.appName, subTitle: MacrosForAll.ERRORMESSAGE.ErrorMessage.rawValue, style: AlertStyle.error)
            })
        }
            
            
        else {
            
            //LODER HIDE
            self.macroObj.hideLoader()
            
            _ = SweetAlert().showAlert(macroObj.appName, subTitle: MacrosForAll.ERRORMESSAGE.NoInternet.rawValue, style: AlertStyle.error)
        }
    }
    
    
    func updateDate()   {
        //  let inputString = self.dateDate
        var strArray = self.dateDate.components(separatedBy:"T")
        print(strArray)
        let date = strArray[0]
        let time = strArray[1]
        // let myTimeStamp = date + " \(time)"
        //strDate = myTimeStamp
        
        
        let str: String = time
        let addTime: Int = 30  //minutes
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        var dateInput: Date? = formatter.date(from: str)
        dateInput = dateInput?.addingTimeInterval(TimeInterval(addTime*60))
        //let endtime = formatter.string(from: dateInput!)
        
        // let dateString = "2014-07-15" // change to your date format
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let myDate = dateFormatter.date(from: date)
        print(myDate)
        
        
        let endDate = Date().addingTimeInterval(12345678)
        let olderDates = date as? NSDate
        let string =  getTimeComponentString(olderDate: myDate!, newerDate: endDate)
        
        // print(nowDate)
        print(endDate)
        print(string)
        
        
        let temStrDate =  timeAgoSinceDate(date: myDate! as NSDate, numericDates: true)
        self.getDate = temStrDate
        
        print("djhsdjdshjj",temStrDate)
    }
    
    func getTimeComponentString(olderDate older: Date,newerDate newer: Date) -> (String?)  {
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        
        let componentsLeftTime = Calendar.current.dateComponents([.minute , .hour , .day,.month, .weekOfMonth,.year], from: older, to: newer)
        
        let year = componentsLeftTime.year ?? 0
        if  year > 0 {
            formatter.allowedUnits = [.year]
            return formatter.string(from: older, to: newer)
        }
        
        
        let month = componentsLeftTime.month ?? 0
        if  month > 0 {
            formatter.allowedUnits = [.month]
            return formatter.string(from: older, to: newer)
        }
        
        let weekOfMonth = componentsLeftTime.weekOfMonth ?? 0
        if  weekOfMonth > 0 {
            formatter.allowedUnits = [.weekOfMonth]
            return formatter.string(from: older, to: newer)
        }
        
        let day = componentsLeftTime.day ?? 0
        if  day > 0 {
            formatter.allowedUnits = [.day]
            return formatter.string(from: older, to: newer)
        }
        
        let hour = componentsLeftTime.hour ?? 0
        if  hour > 0 {
            formatter.allowedUnits = [.hour]
            return formatter.string(from: older, to: newer)
        }
        
        let minute = componentsLeftTime.minute ?? 0
        if  minute > 0 {
            formatter.allowedUnits = [.minute]
            return formatter.string(from: older, to: newer) ?? ""
        }
        
        return nil
    }
    
    func timeAgoSinceDate(date:NSDate, numericDates:Bool) -> String {
        let calendar = NSCalendar.current
        let unitFlags: Set<Calendar.Component> = [.minute, .hour, .day, .weekOfYear, .month, .year, .second]
        let now = NSDate()
        let earliest = now.earlierDate(date as Date)
        let latest = (earliest == now as Date) ? date : now
        let components = calendar.dateComponents(unitFlags, from: earliest as Date,  to: latest as Date)
        
        if (components.year! >= 2) {
            return "\(components.year!) years ago"
        } else if (components.year! >= 1){
            if (numericDates){
                return "1 year ago"
            } else {
                return "Last year"
            }
        } else if (components.month! >= 2) {
            return "\(components.month!) months ago"
        } else if (components.month! >= 1){
            if (numericDates){
                return "1 month ago"
            } else {
                return "Last month"
            }
        } else if (components.weekOfYear! >= 2) {
            return "\(components.weekOfYear!) weeks ago"
        } else if (components.weekOfYear! >= 1){
            if (numericDates){
                return "1 week ago"
            } else {
                return "Last week"
            }
        } else if (components.day! >= 2) {
            return "\(components.day!) days ago"
        } else if (components.day! >= 1){
            if (numericDates){
                return "1 day ago"
            } else {
                return "Yesterday"
            }
        } else if (components.hour! >= 2) {
            return "\(components.hour!) hours ago"
        } else if (components.hour! >= 1){
            if (numericDates){
                return "1 hour ago"
            } else {
                return "An hour ago"
            }
        } else if (components.minute! >= 2) {
            return "\(components.minute!) minutes ago"
        } else if (components.minute! >= 1){
            if (numericDates){
                return "1 minute ago"
            } else {
                return "A minute ago"
            }
        } else if (components.second! >= 3) {
            return "\(components.second!) seconds ago"
        } else {
            return "Just now"
        }
        
    }
}



